= IMPORTANT NOTE =
All of the files in this directory, except the manifest.json,
are copied from the extensions-common directory.  The gulpfile.js
file includes a task to copy the files from the extensions-common
directory to this directory.
